package com.java.ui;
import java.util.Scanner;
import com.java.service.BookService;

public class User {
	
	public static void main(String[] args) {
        BookService service = new BookService();
        boolean val = true;
        
        
        
        Scanner sc = new Scanner(System.in);
     while(val)
        {
        System.out.println("Enter your choice");
        
        System.out.println("1. Enter 1 to view all books");
        System.out.println("2. Enter 2 to add book");
        System.out.println("3. Enter 3 to delete a book");
        System.out.println("4. Enter 4 to search book by name");
        System.out.println("5. Enter 5 to Exit");
        
        int choice = sc.nextInt();
        
        switch(choice)
        {
        case 1: service.veiwBooks();
        break;
        
        case 2: service.addBooks();
        break;
        
        case 3: service.deleteBooks();
        break;
        
        case 4: service.searchBookByName();
        break;
        
        case 5: val = false;
        break;
        
        default: System.out.println("Enter a valid choice");
        }
        
    }

   }

}
