package com.java.dao;

import java.util.Iterator;
import java.util.TreeSet;

import com.java.model.Book;


public class Database {
	TreeSet<Book> booklists = new TreeSet<>();
	
	public Database() {
	
	Book B1= new Book(12,"tales of Narnia", "Robin", 4000);
	Book B2= new Book(1768,"The Girl in the room 101", "Chetan Bhagat", 880);
	Book B3= new Book(128,"Cabin Crew", "Norman" ,650);
	Book B4= new Book(12,"norman newman", "Robin", 689);
	
	booklists.add(B1);
	booklists.add(B2);
	booklists.add(B3);
	booklists.add(B4);
	
	
	}

	public TreeSet<Book> getBooklists() {
		return booklists;
	}

	public void setBooklists(TreeSet<Book> booklists) {
		this.booklists = booklists;
	}

	public Database(TreeSet<Book> booklists) {
		super();
		this.booklists = booklists;
	}
	

}
	
	

