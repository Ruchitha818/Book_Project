package com.java.service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
import java.sql.ResultSet;
import com.java.model.Book;

public class BookJDBCService {
	
	public void viewBooks() throws SQLException
	{
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/demodb1","root","EBD720df@");
			Statement st = conn.createStatement();
			ResultSet records = st.executeQuery("SELECT * FROM demodb1.book");
			while(records.next())
        	{
        		System.out.println(records.getInt(1)+" "+records.getString(2)+" "+records.getString(3)+" "+records.getInt(4));
        	}
		    
   }
	
	public void addBook() throws SQLException
	{
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/demodb1","root","EBD720df@");
			
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter book details ");
			
			
			System.out.println("Enter book id ");
			int bookId = sc.nextInt();
			System.out.println("Enter book name ");
			String name = sc.next();
			System.out.println("Enter name of the author ");
			String author = sc.next();
			System.out.println("Enter book price ");
			int price = sc.nextInt();
			
			PreparedStatement st = conn.prepareStatement("insert into book values(?,?,?,?)");
			st.setInt(1, bookId);
			st.setString(2, name);
			st.setString(3, author);
			st.setInt(4, price);
			
		    int res = st.executeUpdate();
		    if(res == 1)
		    	System.out.println("inserted successfully");
		    else
		    	System.out.println("book cannot be inserted");
   }
	
	public void deleteBook() throws SQLException
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter id of the book you want to delete ");
		int bookid = sc.nextInt();
		
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/demodb1","root","EBD720df@");
		PreparedStatement st = conn.prepareStatement("delete from book where BookId = ?");
		st.setInt(1, bookid);
		int res = st.executeUpdate();
		if(res == 1)
			System.out.println("deleted successfully");
	    else
	    	System.out.println("book cannot be deleted");
		
	}
	
	public void searchBookByName() throws SQLException
	{
		
        Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the name of the book ");	
		String bookname = sc.next();
		
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/demodb1","root","EBD720df@");
		PreparedStatement st = conn.prepareStatement("select * from book where name = ?");
		st.setString(1, bookname);
		
		ResultSet res = st.executeQuery();
		if(res.next())
		    System.out.println(res.getInt(1)+" "+res.getString(2)+" "+res.getString(3)+" "+res.getInt(4));
		else
			System.out.println("book not found");
			    
	   	
	}

}
