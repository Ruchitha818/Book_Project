package com.java.service;

import java.util.TreeSet;
import java.util.Iterator;
import java.util.Scanner;

import com.java.dao.Database;
import com.java.model.Book;

public class BookService {
	
	Database d=new Database();
	
	public void veiwBooks() 
	{
		TreeSet<Book> t = d.getBooklists();
        Iterator<Book> itr = t.iterator();
        
        while(itr.hasNext())
        {
            System.out.println(itr.next());
        }
		
	
	}
	
	public void addBooks() 
	{
		 Scanner sc = new Scanner(System.in);
	        System.out.println("Enter Book details ");
	        
	        
	        System.out.println("Enter the Book Id ");
	        int bookId = sc.nextInt();
	        System.out.println("Enter the Book Name ");
	        String name = sc.next();
	        System.out.println("Enter the name of the Author ");
	        String author = sc.next();
	        System.out.println("Enter BookPrice ");
	        int cost = sc.nextInt();
	        
	        Book b = new Book(bookId,name,author,cost);
	        
	        TreeSet<Book> tr = d.getBooklists();
	        tr.add(b);
	}
	
	public void deleteBooks()
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter BookId of the book you want to delete ");
        int id = sc.nextInt();
        TreeSet<Book> tr = d.getBooklists();
        deleteBook(tr,id);
        
    }
    
    public void deleteBook(TreeSet<Book> t, int bookId)
    {
        Iterator<Book> itr = t.iterator();
        
        while(itr.hasNext())
        {
            Book b = itr.next();
            if(b.getBookId() == bookId)
                { t.remove(b);
                  break;}
        }
    }
    
    public void searchBookByName ()
    {
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Enter the name of the book ");    
        String name = sc.next();
        
        TreeSet<Book> t = d.getBooklists();
        Iterator<Book> itr = t.iterator();
        
        while(itr.hasNext())
        {
            Book b = itr.next();
            if(b.getName().equals(name))
              { System.out.println(b); break;}
        }
    }
	

}