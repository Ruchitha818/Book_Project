package com.ru.dao;

import java.util.Iterator;
import java.util.TreeSet;

import com.ru.model.Book;



public class Database {
     
    TreeSet<Book> bookList = new TreeSet<>();
    
     public Database() {
         
        Book b1 = new Book(7627,"norman newman","norman",500);
        Book b2 = new Book(102,"the tales of Narnia","naina",550);
        Book b3 = new Book(103,"Swami Vivekananda","Bharath Nayak",400);
        Book b4 = new Book(104,"Two States","Chetan Bhagat",300);
        
        bookList.add(b1);
        bookList.add(b2);
        bookList.add(b3);
        bookList.add(b4);
    
    }
    



   public Database(TreeSet<Book> bookList) {
        super();
        this.bookList = bookList;
    }



   public TreeSet<Book> getBookList() {
        return bookList;
    }



   public void setBookList(TreeSet<Book> bookList) {
        this.bookList = bookList;
    }
    
    
}